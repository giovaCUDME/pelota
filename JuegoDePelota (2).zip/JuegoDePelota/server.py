from flask import Flask, render_template

app = Flask(__name__)

CSS_COLORS = [
    'red', 'blue', 'green', 'yellow', 'purple', 'pink'
]

@app.route('/juego')
def juego_defaut():
    return render_template ('juego_defaut.html')

@app.route ('/juego/<int: cantidad>')
def juego_cantidad(cantidad):
    return render_template('juego_cantidad.html', cantidad =cantidad)

@app.route('/juego/<int:cantidad>/<color>')
def juego_cantidad_color(cantidad,color):
    if color.lower() not in CSS_COLORS:
        color = 'red'
    return render_template('juegop_cantidad_color.html', cantidad = cantidad, color = color.lower())

if __name__ == '__main__':
    app.run(debug = True)